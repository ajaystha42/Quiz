import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { tap } from 'rxjs/operators';
import { Options } from '../shared/model/options.model';
import { Questions } from '../shared/model/questions.model';

@Injectable({
  providedIn: 'root'
})
export class QuizService {
  private questions: Questions[] = [];
  constructor(private http: HttpClient) { }

  getlengthofQuestions() {
    return this.questions.length;
  }

  getAllQuestions() {
    this.fetchQuestions();
    return this.questions;
  }

  insertQuestion(name: string, options: Options[]) {
    const question = new Questions(name, options);
    this.questions.push(question);
    this.storeQuestions(question);
  }

  fetchQuestions() {
    return this.http.get('http://localhost:3000/api')
      .pipe(
        tap((questions: Questions[]) => {
          this.questions = questions;
        })
      );
  }

  storeQuestions(question: Questions) {
    this.http.post('http://localhost:3000/api', question)
      .subscribe(
        resData => {
          console.log(resData);

        }
      );

  }

  getById(index: number) {
    return this.questions[index];
  }

}

