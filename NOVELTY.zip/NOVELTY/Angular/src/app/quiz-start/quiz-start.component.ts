import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quiz-start',
  templateUrl: './quiz-start.component.html',
  styleUrls: ['./quiz-start.component.css']
})
export class QuizStartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }


}
