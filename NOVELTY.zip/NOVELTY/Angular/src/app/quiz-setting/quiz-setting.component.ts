import { Component, OnInit } from '@angular/core';
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import { QuizService } from '../service/quiz.service';
import { Questions } from '../shared/model/questions.model';

@Component({
  selector: 'app-quiz-setting',
  templateUrl: './quiz-setting.component.html',
  styleUrls: ['./quiz-setting.component.css']
})
export class QuizSettingComponent implements OnInit {

  quizForm: FormGroup;
  visible: boolean = false;
  nextQuestion: boolean = false;
  questions: Questions[];
  trueCount: number = 0;
  questionsShow: boolean = false;
  isLoading: boolean = false;
  error: string = null;

  constructor(private quizService: QuizService) { }

  ngOnInit(): void {
    this.initForm();
    this.onFetchQuestions();
  }

  onFetchQuestions() {
    this.isLoading = true;
    this.quizService.fetchQuestions().subscribe(
      resData => {
        this.questions = this.quizService.getAllQuestions();
        this.isLoading = false;
        this.questionsShow = true;
      }
    );
  }

  private initForm() {
    let options = new FormArray([]);
    this.quizForm = new FormGroup({
      'name': new FormControl(null, Validators.required),
      'options': options
    });
  }

  get controls() {
    return (<FormArray>this.quizForm.get('options')).controls;
  }

  onAddQuestion() {
    this.nextQuestion = !this.nextQuestion;
    this.visible = false;
    this.quizForm.reset();
    (<FormArray>this.quizForm.get('options')).clear();

  }

  onAddOption() {
    this.visible = true;
    (this.quizForm.get('options') as FormArray).push(
      new FormGroup({
        'answer': new FormControl(null, Validators.required),
        'value': new FormControl(null, [Validators.required, Validators.pattern(/^(t|f)$/)])
      })
    );

  }

  onDeleteOption(index: number) {
    (<FormArray>this.quizForm.get('options')).removeAt(index);

  }


  onSubmit(): void {
    if (!this.quizForm.valid) {
      this.error = 'Please fill the values carefully.';
      return;
    }
    if (this.quizForm.value.options.length >= 2 && this.quizForm.value.options.length <= 5) {
      for (let index = 0; index < this.quizForm.value.options.length; index++) {
        const element = this.quizForm.value.options[index];
        if (element.value === 't') {
          this.trueCount++;
        }
      }

      if (this.trueCount === 1) {
        this.isLoading = true;
        this.quizService.insertQuestion(this.quizForm.value.name, this.quizForm.value.options);
        this.isLoading = false;
        this.onCancel();
      }
      else {
        this.trueCount = 0;
        this.error = 'The number of Correct answer i.e. t must be only one.';

      }
    }
    else {
      this.trueCount = 0;
      this.error = 'The minimum number of options are Two and the maximum number of options are Five.';
    }
  }


  onCancel() {
    this.trueCount = 0;
    this.visible = false;
    this.quizForm.reset();
    this.nextQuestion = false;
    (<FormArray>this.quizForm.get('options')).clear();
  }
  onAlertClose() {
    this.error = null;
  }
}
