import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { QuizSettingComponent } from './quiz-setting/quiz-setting.component';
import { QuizAnswerComponent } from './quiz-answer/quiz-answer.component';
import { QuizStartComponent } from './quiz-start/quiz-start.component';


const routes: Routes = [
  { path: '', redirectTo: '/quizStart', pathMatch: 'full' },
  { path: 'quizStart', component: QuizStartComponent },
  { path: 'quizSetting', component: QuizSettingComponent },
  { path: 'quizTest', component: QuizAnswerComponent },
  { path: '**', redirectTo: '/quizStart' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
