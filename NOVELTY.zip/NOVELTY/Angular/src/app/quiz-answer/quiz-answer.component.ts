import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { QuizService } from '../service/quiz.service';
import { Questions } from '../shared/model/questions.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-quiz-answer',
  templateUrl: './quiz-answer.component.html',
  styleUrls: ['./quiz-answer.component.css']
})
export class QuizAnswerComponent implements OnInit {


  public index: number = 0;
  question: Questions = {
    "question": '',
    "options": [{
      "answer": '',
      "value": ''
    }]
  };
  trueAnswer: string = '';
  questionLength: number;
  isLoading: boolean = false;
  error: string = null;
  alertType: string = '';
  finalAnswer: string = '';
  alert: string = null;
  result: number = 0;

  constructor(private quizService: QuizService, private router: Router) { }

  ngOnInit(): void {
    this.questionLength = this.quizService.getlengthofQuestions();
    this.isLoading = true;
    this.checkIndex();
    this.quizService.fetchQuestions()
      .subscribe(resData => {
        this.isLoading = false;
      });
  }

  onSubmit(form: NgForm) {
    const value = form.value;
    if (!form.valid) {
      this.alertType = 'alert alert-danger';
      this.error = 'Please select any Option first!!';
      return;
    }
    for (let index = 0; index < this.question.options.length; index++) {
      const element = this.question.options[index];
      if (element.value === 't') {
        this.trueAnswer = element.answer;
      }
    }
    this.finalAnswer = value.answer;
    if (value.answer === this.trueAnswer) {
      this.result++;
      this.alertType = 'alert alert-success';
      this.error = 'Your previous answer was correct.Keep it up!!';
    }
    else {
      this.alertType = 'alert alert-danger';
      this.error = 'Your previous answer was incorrect.Think Harder!!';
    }
    this.index++;
    this.checkIndex();
  }


  loadQuestionByIndex() {
    this.question = this.quizService.getById(this.index);

  }

  checkIndex() {
    if (this.index === this.questionLength) {
      if (this.questionLength === 0) {
        this.isLoading = true;
        this.alert = 'The questions are loading!!! Try again in a while';
      } else {
        this.index--;

        if (this.finalAnswer === this.trueAnswer) {
          this.alertType = 'alert alert-success';
          this.error = 'Yayy!!Your answer is correct.';
        } else {
          this.alertType = 'alert alert-danger';
          this.error = 'Oops !! Your answer is incorrect.';
        }

        this.alert = 'Thank you for your time! Your correct answers: ' + this.result + ' out of ' + this.questionLength;
      }
    }
    else {
      this.loadQuestionByIndex();
    }
  }

  onfinalAlertClose() {
    this.alert = null;
    this.router.navigate(['/']);
  }

}
