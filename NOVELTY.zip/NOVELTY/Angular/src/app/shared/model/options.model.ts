export class Options {
    constructor(public answer: string,public value:string) { }
}
