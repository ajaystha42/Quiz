import { Options } from './options.model';

export class Questions {
    constructor(public question: string,public options: Options[]) { }
}
