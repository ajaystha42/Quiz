import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { QuizSettingComponent } from './quiz-setting/quiz-setting.component';
import { QuizAnswerComponent } from './quiz-answer/quiz-answer.component';
import {HttpClientModule} from '@angular/common/http';
import { FormsModule} from '@angular/forms';
import { ReactiveFormsModule} from '@angular/forms';
import { LoadingSpinnerComponent } from './shared/loading-spinner/loading-spinner.component';
import { AlertComponent } from './shared/alert/alert.component';
import { QuizStartComponent } from './quiz-start/quiz-start.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    QuizSettingComponent,
    QuizAnswerComponent,
    LoadingSpinnerComponent,
    AlertComponent,
    QuizStartComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
