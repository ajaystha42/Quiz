const http = require('http')
const cors = require('cors')
const express = require('express')
const bodyParser = require('body-parser')

const sequelize = require('./util/database');
const routes = require('./routes/routes');

const app = express();
app.use(cors());
app.use(bodyParser.json())
app.use(routes);

const server = http.createServer(app);
server.listen(3000);
console.log('Server @ http://localhost:3000')

const Question = require('./models/Question');
const Option = require('./models/Option');
Question.hasMany(Option);

sequelize.sync({
    // force: true
});