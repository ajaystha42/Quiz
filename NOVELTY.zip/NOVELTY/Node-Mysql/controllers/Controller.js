const Question = require('../models/Question');
const options = require('../models/Option');

exports.index = async (req, res, next) => {
    let question = await Question.findAll({
        include: ['options']
    });
    res.json(question);
}

exports.store = async (req, res, next) => {
    let question = await Question.create({
        question: req.body.question
    });

    req.body.options.forEach(async (option) => {
        await question.createOption({
            answer: option.answer,
            value: option.value
        });
    });

    res.json({
        status: 201
    })

}