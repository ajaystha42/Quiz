const express = require('express')
const Router = express.Router();

const Controller = require('./../controllers/Controller');

Router.get('/api', Controller.index); 
Router.post('/api', Controller.store);

module.exports = Router;